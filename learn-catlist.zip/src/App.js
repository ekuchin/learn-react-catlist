import './App.css';
import CatList from './components/CatList.js';

function App() {
  return (
    <div className="App">
      <CatList/>
    </div>
  );
}

export default App;
