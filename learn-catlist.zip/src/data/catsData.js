const catsData =[
    {id:1, name:"Мурзик", breed: "Манул", weight:10, isAngry:true},
    {id:2, name:"Рамзес", breed: "Сфинкс", weight:2, isAngry:true},
    {id:3, name:"Эдуард", breed: "Британец", weight:5, isAngry:false},
    {id:4, name:"Мурка", breed: "Беспородная", weight:4, isAngry:false}
]
export default catsData;